#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""对 notes.json 做机械自检（不做语义判断），供 Agent 在 finalize 前运行。

检查项：
  1. 顶层结构完整；2. paper_card 关键字段非空且有证据；
  3. 章节标题与原文对齐（若提供 paper_text.json）；
  4. 每条 key_point / knowledge_point 都有带页码的证据；
  5. 无笼统出处（“见原文”“见论文”等）；
  6. 知识点 type/status 合法、术语无冲突重复；
  7. 状态自洽（not_reported 不得写成事实）。

用法：
  python3 verify.py --notes notes.json [--paper-text paper_text.json]
输出 JSON：{ ok, checks:[...], issues:[...] }；有问题时 exit 1。
"""
import argparse, json, re, sys

VALID_KNOWLEDGE_TYPES = {"concept", "variable", "method", "finding", "limitation", "other"}
VALID_KNOWLEDGE_STATUS = {"reported", "inferred", "not_reported", "uncertain"}
VAGUE_RE = re.compile(
    r"(见\s*(原文|论文|正文|全文|前文|后文|上图|下表)|passim|见上|见下|同上|略|详见原文)",
    re.IGNORECASE,
)


def _issues(check_name, notes, paper_text):
    issues = []

    # 1) 顶层结构
    for k in ("paper_card", "sections", "knowledge_points", "uncertainty", "change_log"):
        if k not in notes:
            issues.append({"check": check_name, "msg": f"缺少顶层字段 {k}"})

    card = notes.get("paper_card") or {}
    # 2) 论文卡片
    for k in ("title", "research_question", "data"):
        if not str(card.get(k) or "").strip():
            issues.append({"check": "paper_card", "msg": f"paper_card.{k} 为空"})
    for k in ("methods", "key_findings"):
        if not (card.get(k) or []):
            issues.append({"check": "paper_card", "msg": f"paper_card.{k} 为空"})
    if not (card.get("evidence") or {}).get("page"):
        issues.append({"check": "paper_card", "msg": "paper_card.evidence.page 缺失"})

    # 3) 章节对齐
    text_blob = ""
    if paper_text:
        text_blob = "\n".join(p.get("text", "") for p in paper_text.get("pages", []))
    secs = notes.get("sections") or []
    if not secs:
        issues.append({"check": "sections", "msg": "sections 为空（应按原文章节逐章记录）"})
    for s in secs:
        h = str(s.get("heading") or "").strip()
        if not h:
            issues.append({"check": "sections", "msg": f"section {s.get('id')} heading 为空"})
            continue
        if text_blob and h not in text_blob:
            # 允许编号差异，做宽松匹配：去掉编号后是否出现
            norm = re.sub(r"^\s*\d+(\.\d+)*\.?\s*", "", h)
            if norm and norm not in text_blob and h not in text_blob:
                issues.append({"check": "sections", "msg": f"章节标题“{h}”未在原文中定位到"})

    # 4) 证据完整性 + 5) 笼统出处
    def check_evidence(obj, where):
        ev = obj.get("evidence") or {}
        if not ev.get("page"):
            issues.append({"check": "evidence", "msg": f"{where} 证据缺少 page"})
        loc = str(ev.get("locator") or "")
        if VAGUE_RE.search(loc):
            issues.append({"check": "evidence", "msg": f"{where} 定位描述含笼统措辞：{loc}"})

    if not (card.get("evidence") or {}).get("page"):
        pass  # 已在上面报
    for i, s in enumerate(secs):
        for j, kp in enumerate(s.get("key_points") or []):
            check_evidence(kp, f"sections[{i}].key_points[{j}]")

    kps = notes.get("knowledge_points") or []
    seen = {}
    for i, kp in enumerate(kps):
        check_evidence(kp, f"knowledge_points[{i}]")
        t = kp.get("type"); st = kp.get("status")
        if t not in VALID_KNOWLEDGE_TYPES:
            issues.append({"check": "knowledge_points", "msg": f"knowledge_points[{i}].type 非法：{t}"})
        if st not in VALID_KNOWLEDGE_STATUS:
            issues.append({"check": "knowledge_points", "msg": f"knowledge_points[{i}].status 非法：{st}"})
        term = str(kp.get("term") or "").strip()
        if not term:
            issues.append({"check": "knowledge_points", "msg": f"knowledge_points[{i}].term 为空"})
        else:
            key = term.lower()
            if key in seen and seen[key] != str(kp.get("definition") or ""):
                issues.append({"check": "knowledge_points", "msg": f"知识点“{term}”定义与既有条目冲突"})
            seen[key] = str(kp.get("definition") or "")
        # 7) not_reported 不应有“事实性”定义
        if st == "not_reported" and str(kp.get("definition") or "").strip() and len(str(kp.get("definition") or "")) > 60:
            issues.append({"check": "knowledge_points", "msg": f"knowledge_points[{i}] 标为 not_reported 却给出较长定义，疑似把未知写成事实"})

    # 6) uncertainty 项
    for i, u in enumerate(notes.get("uncertainty") or []):
        if not str(u.get("description") or "").strip():
            issues.append({"check": "uncertainty", "msg": f"uncertainty[{i}].description 为空"})

    return issues


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--notes", required=True)
    ap.add_argument("--paper-text", default=None)
    args = ap.parse_args()

    with open(args.notes, encoding="utf-8") as f:
        notes = json.load(f)
    paper_text = None
    if args.paper_text:
        try:
            with open(args.paper_text, encoding="utf-8") as f:
                paper_text = json.load(f)
        except FileNotFoundError:
            pass

    checks = ["structure", "paper_card", "sections", "evidence", "knowledge_points", "uncertainty"]
    issues = _issues("verify", notes, paper_text)
    result = {
        "ok": len(issues) == 0,
        "checks": checks,
        "issues": issues,
        "stats": {
            "sections": len(notes.get("sections") or []),
            "knowledge_points": len(notes.get("knowledge_points") or []),
            "uncertainty": len(notes.get("uncertainty") or []),
        },
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))
    if issues:
        sys.exit(1)


if __name__ == "__main__":
    main()
